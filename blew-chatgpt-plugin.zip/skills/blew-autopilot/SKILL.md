---
name: blew-autopilot
description: Draft and publish high-impact social media posts directly to X (Twitter) and LinkedIn via Blew MCP.
---

# Blew Social Media Autopilot

Use this skill when the user asks to write, draft, schedule, or publish social media updates to X (formerly Twitter) and/or LinkedIn.

## Guidelines
1. **Drafting:** When the user asks to write a post or share an insight, craft engaging copy tailored to the platform (concise for X, insightful and structured for LinkedIn).
2. **Explicit Confirmation:** Before calling the publication tool, display the draft to the user and request confirmation (e.g., "Would you like me to publish this to X and LinkedIn?").
3. **Publishing:** Once approved, call the `publish_to_social` tool with `platform` ('twitter', 'linkedin', or 'both') and `post_content`.
4. **Quotas:** If the user inquires about remaining posts or balance, call the `check_quota` tool.
